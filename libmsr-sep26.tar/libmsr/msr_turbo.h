#ifndef MSR_TURBO_H
#define MSR_TURBO_H
void enable_turbo( int cpu );
void disable_turbo( int cpu );
void enable_all_turbo( );
void disable_all_turbo( );
void dump_turbo( );
#endif //MSR_TURBO_H


