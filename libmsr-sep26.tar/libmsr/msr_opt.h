#ifndef MSR_OPT_H
#define MSR_OPT_H

void get_env_variables(struct rapl_state_s *s);
void set_power_bounds();
#endif //MSR_OPT_H
